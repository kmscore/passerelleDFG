HULTOG ENGRAVED
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is a clawed-in-clay-bricks interpretation of one of my own favorite fonts, Hultog. I designed this font to play nicely with my other �engraved� fonts (especially Temphis Engraven, but also Regal Demise), with the same rough-hewn look and � since I�ll be using them on the same page together � the same direction for the source of light. It�s scaled the same as Hultog itself, of course, but I didn�t bother cloning the metrics. Hultog Engraved is a full-keyboard set, freeware for personal use. Enjoy!

This font is copyright � 2006 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
